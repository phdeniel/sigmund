#/bin/sh
tar --transform 's,^,cthon04-1/,' -c -f cthon04.tar * && rpmbuild -ta  cthon04.tar  && rm  cthon04.tar


